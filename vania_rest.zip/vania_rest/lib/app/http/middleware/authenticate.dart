import 'package:vania/vania.dart';

class AuthenticateMiddleware extends Authenticate {}
