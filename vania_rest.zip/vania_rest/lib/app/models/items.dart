import 'package:vania/vania.dart';

class Items extends Model {

  
  Items(){
    super.table('items');
  }
}