import 'package:vania/vania.dart';

class Product extends Model {

  Product(){
    super.table('product');
  }
}