import 'package:vania/vania.dart';

class User extends Model {
  User() {
    super.table('users');
  }
}
