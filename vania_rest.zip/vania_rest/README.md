
# Vania Dart backend framework

![Vania](https://vdart.dev/img/logo.png)

[Documentation](https://vdart.dev)

[Github](https://github.com/vania-dart/framework)

[pub.dev](https://pub.dev/packages/vania)

YouTube Video [Quick Start](https://www.youtube.com/watch?v=k8ol0F4bDKs)

[![Quick Start](http://img.youtube.com/vi/k8ol0F4bDKs/0.jpg)](https://www.youtube.com/watch?v=k8ol0F4bDKs "Quick Start")
